import 'dart:convert';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';

Future<void> uploadCitiesToFirestore() async {
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final String jsonString = await rootBundle.loadString('assets/config/cities.json');
  final Map<String, dynamic> jsonData = json.decode(jsonString);
  final List<dynamic> cities = jsonData['cities'];

  for (int i = 0; i < cities.length; i++) {
    final city = cities[i];
    final String cityId = city['name'].toLowerCase();

    await firestore.collection('cities').doc(cityId).set({
      'name': city['name'],
      'step': city['step'],
      'description': 'Description of ${city['name']}',
      'badgeImageUrl': city['badgeImageUrl'],
      'order': i,
    });

    print('✅ 已上传城市: ${city['name']}');
  }
}
