import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:pedometer/pedometer.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class StepService {
  StreamSubscription<StepCount>? _subscription;
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  int _initialSteps = 0;
  bool _initialized = false;

  /// 启动步数监听
  void startListening() {
    _subscription = Pedometer.stepCountStream.listen(
      _onStepCount,
      onError: _onStepError,
      cancelOnError: true,
    );
  }

  /// 步数更新时调用
  void _onStepCount(StepCount event) async {
    try {
      final uid = _auth.currentUser?.uid;
      if (uid == null) return;

      final userRef = _firestore.collection('users').doc(uid);
      final userDoc = await userRef.get();
      if (!userDoc.exists) return;

      final userData = userDoc.data()!;
      int previousStep = userData['currentStep'] ?? 0;

      // 第一次记录基准步数
      if (!_initialized) {
        _initialSteps = event.steps;
        _initialized = true;
        return;
      }

      // 计算本次新增步数
      int delta = event.steps - _initialSteps;
      if (delta <= 0) return; // 无新增步数，或步数被系统重置

      int newStep = previousStep + delta;
      _initialSteps = event.steps;

      // 更新用户步数
      await userRef.update({'currentStep': newStep});

      // 检查是否达成新城市解锁条件
      await _checkAndUnlockCities(userRef, userData, newStep);
    } catch (e) {
      print('步数处理异常: $e');
    }
  }

  /// 检查步数是否达到新城市要求，并更新徽章与 currentCity
  Future<void> _checkAndUnlockCities(
      DocumentReference userRef, Map<String, dynamic> userData, int newStep) async {
    final List<String> badges = List<String>.from(userData['badges'] ?? []);
    final cities = await _loadCitiesConfig();

    for (var city in cities) {
      final String name = city['name'];
      final int requiredSteps = city['step'];

      if (newStep >= requiredSteps && !badges.contains(name)) {
        badges.add(name);
        await userRef.update({
          'badges': badges,
          'currentCity': name,
        });
        print('🎉 解锁城市: $name');
      }
    }
  }

  /// 从 assets/config/cities.json 加载城市配置
  Future<List<dynamic>> _loadCitiesConfig() async {
    final String jsonString =
        await rootBundle.loadString('assets/config/cities.json');
    final Map<String, dynamic> jsonData = json.decode(jsonString);
    return jsonData['cities'] ?? [];
  }

  void _onStepError(error) {
    print('步数监听错误: $error');
  }

  void dispose() {
    _subscription?.cancel();
  }
}