import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// 登录
  Future<User?> loginWithEmail(String email, String password) async {
    try {
      await _auth.signOut(); // 清除旧状态
      final result = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      print('✅ 登录成功');
      return result.user;
    } catch (e) {
      print('❌ 登录失败: $e');
      return null;
    }
  }

  /// 注册用户并初始化 Firestore 文档
  Future<User?> registerWithEmail(String email, String password) async {
    try {
      await _auth.signOut(); // 清除旧状态
      final result = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      await _createUserDoc(result.user!, isGuest: false);
      print('✅ 注册成功，Firestore 文档已创建');
      return result.user;
    } catch (e) {
      print('❌ 注册失败: $e');
      return null;
    }
  }

  /// 游客登录（匿名）
  Future<User?> signInAsGuest() async {
    try {
      await _auth.signOut(); // 清除旧状态
      final result = await _auth.signInAnonymously();
      await _createUserDoc(result.user!, isGuest: true);
      print('✅ 游客登录成功');
      return result.user;
    } catch (e) {
      print('❌ 游客登录失败: $e');
      return null;
    }
  }

  /// 创建 Firestore 用户文档
  Future<void> _createUserDoc(User user, {required bool isGuest}) async {
    final docRef = _firestore.collection('users').doc(user.uid);
    final doc = await docRef.get();

    if (!doc.exists) {
      await docRef.set({
        'email': isGuest ? 'guest' : user.email ?? '',
        'nickname': isGuest ? 'Guest User' : 'New User',
        'avatarUrl': 'https://your-default-image-url.com/avatar.png',
        'currentStep': 0,
        'cat': '', // 空值，用户进入 app 后自己选择角色
        'badges': ['Milan'],
        'isGuest': isGuest,
        'createdAt': FieldValue.serverTimestamp(),
      });
      print('✅ Firestore 用户文档初始化成功');
    }
  }
}
