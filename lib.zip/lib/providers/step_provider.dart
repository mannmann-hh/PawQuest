import 'dart:async';
import 'package:flutter/material.dart';
import 'package:pedometer/pedometer.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class StepProvider with ChangeNotifier {
  int _steps = 0;
  int get steps => _steps;

  StreamSubscription<StepCount>? _subscription;
  int? _initialSensorSteps;

  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  /// 🚀 初始化时加载 Firestore 中保存的步数
  Future<void> loadSavedSteps() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;

    final doc = await _firestore.collection('users').doc(uid).get();
    if (doc.exists && doc.data()?['currentStep'] != null) {
      _steps = doc.data()!['currentStep'];
      notifyListeners();
    }
  }

  /// 🐾 真机：开始监听系统传感器步数
  void startListening() {
    _subscription = Pedometer.stepCountStream.listen(
      _onStep,
      onError: (error) => print('步数监听错误: $error'),
    );
  }

  void _onStep(StepCount event) async {
    if (_initialSensorSteps == null) {
      _initialSensorSteps = event.steps;
      return;
    }

    int delta = event.steps - _initialSensorSteps!;
    if (delta <= 0) return;

    _steps += delta;
    _initialSensorSteps = event.steps;
    notifyListeners();

    await _saveToFirestore();
  }

  /// 🧪 模拟器：调试用按钮手动加步数
  void addDebugSteps(int count) async {
    _steps += count;
    notifyListeners();
    await _saveToFirestore();
  }

  /// 🔁 保存当前步数到 Firestore
  Future<void> _saveToFirestore() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;

    await _firestore.collection('users').doc(uid).update({
      'currentStep': _steps,
    });
  }

  /// ❌ 退出时清理监听
  void disposeListener() {
    _subscription?.cancel();
  }
}