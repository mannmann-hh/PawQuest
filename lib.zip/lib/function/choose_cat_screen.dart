import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../screens/main_screen.dart';




class ChooseCatScreen extends StatefulWidget {
  @override
  _ChooseCatScreenState createState() => _ChooseCatScreenState();
}

class _ChooseCatScreenState extends State<ChooseCatScreen> {
  final List<String> cats = [
    'cat1', 'cat2', 'cat3',
    'cat4', 'cat5', 'cat6',
    'cat7', 'cat8', 'cat9',
  ];

  String? selectedCat;
  final user = FirebaseAuth.instance.currentUser;

  @override
  void initState() {
    super.initState();
    _loadSelectedCat();
  }

  /// 读取用户当前选择的猫角色
  Future<void> _loadSelectedCat() async {
    if (user != null) {
      final doc = await FirebaseFirestore.instance.collection('users').doc(user!.uid).get();
      setState(() {
        selectedCat = doc.data()?['cat'];
      });
    }
  }

  /// 用户选择猫角色并更新数据库
  Future<void> _selectCat(String catName) async {
    if (user != null) {
      await FirebaseFirestore.instance.collection('users').doc(user!.uid).update({
        'cat': catName,
      });
      setState(() {
        selectedCat = catName;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('🐱 你选择了 $catName')),
      );
    }
  }

  /// 构造本地图片路径
  String _catAssetPath(String catName) {
    return 'assets/images/cats/$catName.png';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('选择你的猫咪角色')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            SizedBox(height: 8),
            Text(
              selectedCat != null
                  ? '你当前选择的是：$selectedCat'
                  : '请选择你喜欢的猫咪角色',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
            SizedBox(height: 16),
            Expanded(
              child: GridView.builder(
                itemCount: cats.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                ),
                itemBuilder: (context, index) {
                  final catName = cats[index];
                  final isSelected = selectedCat == catName;

                  return GestureDetector(
                    onTap: () => _selectCat(catName),
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: isSelected ? Colors.green : Colors.transparent,
                          width: 3,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(6.0),
                              child: Image.asset(
                                _catAssetPath(catName),
                                fit: BoxFit.contain,
                              ),
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(catName),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            SizedBox(height: 12),
            ElevatedButton(
  onPressed: () {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const MainScreen()), // 或 HomeScreen
    );
  },
  child: Text('✅ 保存并返回主页'),
)
,
            SizedBox(height: 12),
          ],
        ),
      ),
    );
  }
}
