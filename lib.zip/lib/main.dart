import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:provider/provider.dart';
import 'package:pawquest/providers/step_provider.dart';
import 'package:pawquest/screens/main_screen.dart'; // 主界面
import 'package:pawquest/init/init_cities_firestore.dart'; // 初始化城市数据

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // 可选：首次上传城市数据（如不需要可注释）
  await uploadCitiesToFirestore();

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) {
          final stepProvider = StepProvider();
          stepProvider.loadSavedSteps();
          stepProvider.startListening();
          return stepProvider;
        }),
      ],
      child: const PawQuestApp(),
    ),
  );
}

class PawQuestApp extends StatelessWidget {
  const PawQuestApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PawQuest',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MainScreen(), // ✅ 启动首页设为 MainScreen
    );
  }
}
