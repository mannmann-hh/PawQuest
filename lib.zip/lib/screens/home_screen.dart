import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:pawquest/providers/step_provider.dart';
import 'world_map_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final steps = context.watch<StepProvider>().steps;
    final stepProvider = Provider.of<StepProvider>(context, listen: false);

    return Stack(
      children: [
        // 背景图
        Positioned.fill(
          child: Image.asset(
            'assets/images/backgrounds/city1.png',
            fit: BoxFit.cover,
          ),
        ),

        // 顶部中间显示步数
        Positioned(
          top: 100,
          left: 0,
          right: 0,
          child: Column(
            children: [
              const Text(
                'Your Steps',
                style: TextStyle(
                  fontSize: 24,
                  color: Colors.white,
                  shadows: [Shadow(blurRadius: 4, color: Colors.black)],
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '$steps',
                style: const TextStyle(
                  fontSize: 48,
                  fontWeight: FontWeight.bold,
                  color: Colors.yellow,
                  shadows: [Shadow(blurRadius: 4, color: Colors.black)],
                ),
              ),
            ],
          ),
        ),

        // 调试按钮
        if (kDebugMode)
          Positioned(
            top: 40,
            left: 20,
            child: ElevatedButton(
              onPressed: () => stepProvider.addDebugSteps(100),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
              ),
              child: const Text('+100 步'),
            ),
          ),

        // 小猫角色
      FutureBuilder<DocumentSnapshot>(
  future: FirebaseFirestore.instance
      .collection('users')
      .doc(FirebaseAuth.instance.currentUser!.uid)
      .get(),
  builder: (context, snapshot) {
    if (!snapshot.hasData) {
      return const SizedBox(); // or loading spinner
    }

    final data = snapshot.data!.data() as Map<String, dynamic>?;
    final catName = data?['cat'] ?? 'cat1'; // fallback to cat1 if missing

    return Align(
      alignment: Alignment.bottomCenter,
      child: Image.asset(
        'assets/images/cats/$catName.png',
        width: 128,
        height: 128,
      ),
    );
  },
),

        // 地球按钮
        Positioned(
          top: 40,
          right: 20,
          child: IconButton(
            icon: const Icon(Icons.public, color: Color.fromARGB(255, 4, 89, 132)),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => WorldMapScreen()),
              );
            },
          ),
        ),
      ],
    );
  }
}