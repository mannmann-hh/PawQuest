import 'package:flutter/material.dart';

class BadgeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          '🏅 Badge Collection',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}

