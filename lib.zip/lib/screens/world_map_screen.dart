import 'package:flutter/material.dart';
import 'city_detail_screen.dart';

class WorldMapScreen extends StatelessWidget {
  final List<CityData> cities = [
  CityData(
    name: 'Milan',
    dx: 120,
    dy: 200,
    visited: true,
    isCurrent: true,
    badgeImagePath: 'assets/images/badges/milan.png',
    description: 'Welcome to Milan! 🏛️ Fashion and history in one city.',
  ),
  CityData(
    name: 'Paris',
    dx: 160,
    dy: 180,
    visited: true,
    isCurrent: false,
    badgeImagePath: 'assets/images/badges/paris.png',
    description: 'Bienvenue à Paris! 🗼 Enjoy croissants and the Eiffel Tower.',
  ),
  CityData(
    name: 'New York',
    dx: 300,
    dy: 250,
    visited: false,
    isCurrent: false,
    badgeImagePath: 'assets/images/badges/newyork.png',
    description: 'New York City – the city that never sleeps! 🌆',
  ),
];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('World Map'),
        backgroundColor: Colors.black87,
        leading: IconButton(
    icon: Icon(Icons.arrow_back, color: Colors.white),
    onPressed: () {
      Navigator.pop(context); // ← 这就是返回上一页
    },
  ),
      ),
      body: InteractiveViewer(
        minScale: 1.0,
        maxScale: 3.0,
        child: Stack(
          children: [
            Image.asset('assets/images/world_map.png'),
            // 城市点位
            ...cities.map((city) => Positioned(
                  left: city.dx,
                  top: city.dy,
                  child: GestureDetector(
                    onTap: () {
                      // 可跳转未来的城市详情页面
                      showDialog(
                        context: context,
                        builder: (_) => AlertDialog(
                          title: Text(city.name),
                          content: Text(city.visited
                              ? 'You have visited this city!'
                              : 'You have not visited this city yet.'),
                        ),
                      );
                    },
                    child: Column(
                      children: [
                        if (city.isCurrent)
                          Icon(Icons.pets, color: Colors.redAccent, size: 24),
                        if (city.visited && !city.isCurrent)
                          Text('🏅', style: TextStyle(fontSize: 18)),
                        Container(
                          width: 10,
                          height: 10,
                          decoration: BoxDecoration(
                            color: city.visited
                                ? Colors.green
                                : Colors.grey.withOpacity(0.6),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ),
    );
  }
}

class CityData {
  final String name;
  final double dx;
  final double dy;
  final bool visited;
  final bool isCurrent;
  final String badgeImagePath;
  final String description;

  CityData({
    required this.name,
    required this.dx,
    required this.dy,
    required this.visited,
    required this.isCurrent,
    required this.badgeImagePath,
    required this.description,
  });
}

