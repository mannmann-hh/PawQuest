import 'package:flutter/material.dart';
import 'main_screen.dart'; // 替换为你的主界面类名

class SplashScreen extends StatefulWidget {
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeIn;

  @override
  void initState() {
    super.initState();

    // 3秒淡入动画
    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 5),
    );

    _fadeIn = Tween<double>(begin: 0, end: 1).animate(_controller);

    _controller.forward();

    // 等动画完成后延迟1秒跳转
    Future.delayed(Duration(seconds: 4), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => MainScreen()),
      );
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black, // 全黑背景
      body: SizedBox.expand(
        child: FadeTransition(
          opacity: _fadeIn,
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Image.asset(
              //   'assets/images/logo.png', // 你的全屏像素图
              //   fit: BoxFit.cover,
              //   width: double.infinity,
              //   height: double.infinity,
              // ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Image.asset(
                    'assets/images/logo.png',
                    fit: BoxFit.cover,
                  ),
                  SizedBox(height: 20),
                  Text(
                    'PawQuest',
                    style: TextStyle(
                      fontFamily: 'Pixel',
                      fontSize: 28,
                      color: Colors.white,
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
