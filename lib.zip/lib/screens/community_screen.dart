import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';


class CommunityScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('🌐 Community Feed'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('posts')
            .orderBy('timestamp', descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

          final posts = snapshot.data!.docs;

          return ListView.builder(
            itemCount: posts.length,
            itemBuilder: (context, index) {
              final post = posts[index].data() as Map<String, dynamic>;
              return ListTile(
                title: Text(post['authorName'] ?? '匿名用户'),
                subtitle: Text(post['content'] ?? ''),
                trailing: Text(post['timestamp']?.toDate().toString().substring(0, 16) ?? ''),
                onTap: () {
                  // 将来跳转到评论页面
                },
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.add),
        onPressed: () {
          _showPostDialog(context);
        },
      ),
    );
  }

void _showPostDialog(BuildContext context) {
  final _controller = TextEditingController();
  final user = FirebaseAuth.instance.currentUser;

  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: Text('发布新帖'),
      content: TextField(
        controller: _controller,
        decoration: InputDecoration(hintText: '说点什么...'),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: Text('取消'),
        ),
        ElevatedButton(
          onPressed: () async {
            final content = _controller.text.trim();
            if (content.isNotEmpty && user != null) {
              await FirebaseFirestore.instance.collection('posts').add({
                'authorId': user.uid,
                'authorName': user.displayName ?? '匿名用户',
                'content': content,
                'timestamp': FieldValue.serverTimestamp(),
              });
            }
            Navigator.pop(context);
          },
          child: Text('发布'),
        ),
      ],
    ),
  );
}
}